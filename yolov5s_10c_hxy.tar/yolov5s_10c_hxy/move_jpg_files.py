import os
import shutil
# filePath = '/zhangwt13/yolov5_zhangwt13/tensorrtx/yolov5s_10c_hxy'
# filePath1 = filePath + "/test"
# list_files = os.listdir(filePath1)
# for i in range(len(list_files)):
#     file_name = list_files[i]
#     print(file_name)
#     if file_name.split(".")[-1] == 'jpg':
#         print("ok")
#         orign_path = filePath + "/test/" + file_name
#         new_path = filePath + "/test1/" + file_name
#         shutil.move(orign_path, new_path)

filePath = '/zhangwt13/yolov5_zhangwt13/tensorrtx/yolov5s_10c_hxy/test'
list_files = os.listdir(filePath)
print(len(list_files))
